﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for B2BMobileModel
/// </summary>
public class B2BMobileModel
{
    public int CentreID { get; set; }
    public string RoleName { get; set; }
    public string UserName { get; set; }
    public int Employee_Id { get; set; }
    public string NAME { get; set; }
    public string RoleID { get; set; }
    public string Centre { get; set; }
    public string Type1 { get; set; }
    public int IsInvoice { get; set; }
    public int IsSalesTeamMember { get; set; }
    public int IsHideRate { get; set; }
    public string Mobile { get; set; }
    public int panel_id { get; set; }
    public string AccessStoreLocation { get; set; }
    public string AccessDepartment { get; set; }
    public string Panel_Name { get; set; }
}
public class B2BLogin
{
    [Required(ErrorMessage = "username should not blank")]
    public string username { get; set; }
    [Required(ErrorMessage = "password should not blank")]
    public string password { get; set; }
}
public class ForgotPassword
{
   public  string UserName{get;set;}
   public string Mobile {get;set;}
   public string Email { get; set; }
   public string OTP { get; set; }
}
