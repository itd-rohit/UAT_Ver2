﻿using MySql.Data.MySqlClient;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Web.Http;

[Route("api/[controller]/[action]")]
public class B2BMobileController : ApiController
{
    string url = Resources.Resource.RemoteLink;
    // POST: api/Authenticate
    [ActionName("Login")]
    public HttpResponseMessage Login([FromBody]B2BLogin _login)
    {
        HttpError err = new HttpError();
       
        if (_login == null)
        {
            err.Add("status", false);
            err.Add("message", "Invalid JSON Format");
            err.Add("data", "");
            return Request.CreateErrorResponse(HttpStatusCode.BadRequest, err);
        }
        if (string.IsNullOrWhiteSpace(_login.username))
        {
            err.Add("status", false);
            err.Add("message", "username can't be blank");
            err.Add("data", "");
            return Request.CreateErrorResponse(HttpStatusCode.BadRequest, err);
        }
        if (string.IsNullOrWhiteSpace(_login.password))
        {
            err.Add("status", false);
            err.Add("message", "password can't be blank");
            err.Add("data", "");
            return Request.CreateErrorResponse(HttpStatusCode.BadRequest, err);
        }

            MySqlConnection con = Util.GetMySqlCon();
            con.Open();
            try
            {
                StringBuilder sb = new StringBuilder();
                sb.Append("SELECT cm.Centre,cm.Type1,fl.EmployeeID,fl.EmployeeID as Employee_Id,pm.company_name as Panel_Name, pm.panel_id ,fl.UserName,Concat(em.Title,'',em.Name) AS NAME,em.Mobile,fl.RoleID,rm.RoleName,fl.CentreID,pm.IsInvoice,em.IsSalesTeamMember,em.`AccessDepartment`,em.IsHideRate,IFNULL(em.AccessStoreLocation,'')AccessStoreLocation  ");
                sb.Append(" FROM f_login fl INNER JOIN employee_master em on fl.EmployeeID = em.Employee_ID ");
                sb.Append(" INNER JOIN centre_master cm ON cm.CentreID=fl.CentreID ");
                sb.Append(" INNER JOIN f_rolemaster rm ON rm.ID=fl.RoleID ");
                sb.Append(" INNER JOIN f_panel_Master pm ON pm.CentreID=cm.CentreID AND pm.PanelType='Centre' WHERE fl.Active = 1 AND em.IsActive=1 ");
                sb.Append(" AND BINARY PASSWORD(fl.UserName) = PASSWORD(@Username) AND BINARY PASSWORD(fl.Password) = PASSWORD(@Password)  ORDER BY fl.isDefault desc LIMIT 1");
                DataTable dt = MySqlHelper.ExecuteDataset(con, CommandType.Text, sb.ToString(),
                 new MySqlParameter("@Username", _login.username),
                 new MySqlParameter("@Password", _login.password)).Tables[0];
                
                    if (dt.Rows.Count > 0)
                    {
                        sb = new StringBuilder();
                        sb.Append(" INSERT INTO f_login_detail(RoleID,EmployeeID,EmployeeName,UserName,CentreID,Browser,ipAddress,HostName) ");
                        sb.Append(" VALUES(@RoleID,@EmployeeID,@EmployeeName,@UserName,@CentreID,@Browser,@ipAddress,@HostName) ");
                        MySqlHelper.ExecuteNonQuery(con, CommandType.Text, sb.ToString(),
                            new MySqlParameter("@RoleID", Util.GetString(dt.Rows[0]["RoleID"])), new MySqlParameter("@EmployeeID", Util.GetString(dt.Rows[0]["EmployeeID"])),
                            new MySqlParameter("@EmployeeName", Util.GetString(dt.Rows[0]["NAME"])), new MySqlParameter("@UserName", _login.username),
                            new MySqlParameter("@CentreID", Util.GetString(dt.Rows[0]["CentreID"])), new MySqlParameter("@HostName", "Mobile"));

                        err.Add("status", true);
                        err.Add("message", "Success");
                        err.Add("data", JArray.FromObject(dt));
                        return Request.CreateErrorResponse(HttpStatusCode.OK, err);
                    }
                    else
                    {
                      
                        err.Add("status", false);
                        err.Add("message", "No Record Found");
                        err.Add("data", "");
                        return Request.CreateErrorResponse(HttpStatusCode.BadRequest, err);
                    }
                

            }
            catch (Exception ex)
            {
                err.Add("status", false);
                err.Add("message", "No Record Found");
                err.Add("data", "");
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, err);
            }
            finally
            {
                con.Close();
                con.Dispose();
            }
    }
    [HttpGet]
    [ActionName("GetPageData")]
    public HttpResponseMessage GetPageData()
    {
         MySqlConnection con=Util.GetMySqlCon();
            con.Open();
            HttpError err = new HttpError();
        try
        {
            using (DataTable dt = MySqlHelper.ExecuteDataset(con, CommandType.Text, "SELECT ID,Color,WelcomeContent as WelcomePageContent,IFNULL(WelcomeText,'')WelcomeText,Concat('" + url + "/Design/B2CMobile/Images/','',if(Logo='','default.jpg',Logo))Logo,'ITDOSE INFO SYSTEMS PVT LTD' HeaderText,IsShowPoweredBy,IFNULL(HelpLineNo24x7,'')HelpLineNo24x7 from App_B2B_Setting Limit 1 ").Tables[0])
            {
                err.Add("status", true);
                err.Add("message", "Success");
                err.Add("data", JArray.FromObject(dt));
                return Request.CreateErrorResponse(HttpStatusCode.OK, err);
            }
        }
        catch (Exception ex)
        {
            ClassLog cl = new ClassLog();
            cl.errLog(ex);
            err.Add("status", false);
            err.Add("message", "No Record Found");
            err.Add("data", "");
            return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, err);
        }
        finally
        {
            con.Close();
            con.Dispose();
        }
    }
    [HttpPost]
    [ActionName("ForgotPassword")]
    public HttpResponseMessage ForgotPassword([FromBody]ForgotPassword _forgotpassword)
    {
        HttpError err = new HttpError();
        string EmpId = "";
        if (_forgotpassword == null)
        {
            err.Add("status", false);
            err.Add("message", "Invalid JSON Format");
            err.Add("data", "");
            return Request.CreateErrorResponse(HttpStatusCode.BadRequest, err);
        }
        if (string.IsNullOrWhiteSpace(_forgotpassword.Mobile))
        {
            err.Add("status", false);
            err.Add("message", "Mobile can't be blank");
            err.Add("data", "");
            return Request.CreateErrorResponse(HttpStatusCode.BadRequest, err);
        }
        if (string.IsNullOrWhiteSpace(_forgotpassword.UserName))
        {
            err.Add("status", false);
            err.Add("message", "UserName can't be blank");
            err.Add("data", "");
            return Request.CreateErrorResponse(HttpStatusCode.BadRequest, err);
        }
       
        MySqlConnection con = Util.GetMySqlCon();
        con.Open();
        MySqlTransaction tnx = con.BeginTransaction(IsolationLevel.Serializable);
        try
        {

            EmpId = Util.GetString(MySqlHelper.ExecuteScalar(tnx, CommandType.Text,
                    "SELECT f.`EmployeeID` FROM `f_login` f JOIN `employee_master` e ON f.`EmployeeID`=e.`Employee_ID` WHERE  f.`UserName`=@UserName  AND e.`IsActive`=@IsActive AND ( mobile=@Mobile OR e.Email=@Email)LIMIT 1;",
                     new MySqlParameter("@IsActive", "1"),
                new MySqlParameter("@Mobile", _forgotpassword.Mobile),
                new MySqlParameter("@UserName", _forgotpassword.UserName),
                new MySqlParameter("@Email", _forgotpassword.Email)
                ));
            if (EmpId == "")
            {
                err.Add("status", false);
                err.Add("message", "Invalid Username/Mobile");
                err.Add("data", "");
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, err);
            }
            else
            {
                int limit = 0;
                if (limit == 3)
                {
                    err.Add("status", false);
                    err.Add("message", "Get Otp request exceeded.You can request only 3 times a day");
                    err.Add("data", "");
                    return Request.CreateErrorResponse(HttpStatusCode.BadRequest, err);

                }
                else
                {
                    if (Util.GetInt(MySqlHelper.ExecuteScalar(tnx, CommandType.Text, "SELECT COUNT(*) FROM forget_password WHERE dtEntry>=CURRENT_DATE() AND employee_ID=@Employee_Id and UserType=@UserType", new MySqlParameter("@Employee_Id", EmpId), new MySqlParameter("@UserType", "Employee"))) < 3)
                    {
                        string mobileOtp = Util.getOTP;
                        MySqlHelper.ExecuteNonQuery(tnx, CommandType.Text,
                            "INSERT INTO `forget_password`(`code`,`Employee_Id`,`dtEntry`,UserType) VALUES(@code,@Employee_Id,@dtEntry,@UserType)",
                            new MySqlParameter("@code", mobileOtp),
                            new MySqlParameter("@Employee_Id", EmpId),
                            new MySqlParameter("@dtEntry", DateTime.Now),
                            new MySqlParameter("@UserType", "Employee"));

                        string OTPText = "Your OTP is: " + mobileOtp;
                        if (_forgotpassword.Mobile != string.Empty)
                        {
                            MySqlHelper.ExecuteNonQuery(tnx, CommandType.Text,
                            "INSERT INTO `sms`(`MOBILE_NO`,`SMS_TEXT`,`IsSend`,UserID,SMS_Type) VALUES(@MOBILE,@OTPText,@IsSend,@Employee_Id,@SMSType)",
                            new MySqlParameter("@MOBILE", _forgotpassword.Mobile),
                            new MySqlParameter("@OTPText", OTPText),
                            new MySqlParameter("@IsSend", 0),
                            new MySqlParameter("@Employee_Id", EmpId),
                            new MySqlParameter("@SMSType", "OTP"));

                            err.Add("status", true);
                            err.Add("message", "OTP sent");
                            err.Add("data", mobileOtp);
                        }
                        else if (_forgotpassword.Email != string.Empty)
                        {
                            ReportEmailClass objEmail = new ReportEmailClass();
                            objEmail.sendEmailOTP(_forgotpassword.Email, "Your OTP", "Your OTP is: " + mobileOtp, "", "", EmpId, "Employee");
                            err.Add("status", true);
                            err.Add("message", "OTP sent");
                            err.Add("data", mobileOtp);
                        }
                        tnx.Commit();
                        return Request.CreateErrorResponse(HttpStatusCode.OK, err);
                    }
                    else
                    {
                        err.Add("status", false);
                        err.Add("message", "OTP can be sent for maximum 2 times in a day. Please contact Administrator.");
                        err.Add("data", "");
                        return Request.CreateErrorResponse(HttpStatusCode.BadRequest, err);
                    }
                   
                }

            }
            
        }
        catch (Exception ex)
        {
            tnx.Rollback();
            err.Add("status", false);
            err.Add("message", "Error Occured. Please contact Administrator.");
            err.Add("data", "");
            return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, err);
        }
        finally
        {
          
            tnx.Dispose();
            con.Close();
            con.Dispose();
        }
    }
    [HttpGet]
    public HttpResponseMessage GetDashBoardDetails(string EmployeeID)
    {
        HttpError err = new HttpError();
        if (string.IsNullOrWhiteSpace(EmployeeID))
        {
            err.Add("status", false);
            err.Add("message", "EmployeeID can't be blank");
            err.Add("data", "");
            return Request.CreateErrorResponse(HttpStatusCode.BadRequest, err);
        }
        MySqlConnection con = Util.GetMySqlCon();
        con.Open();
        DataTable dt = new DataTable();
        try
        {
            StringBuilder sb = new StringBuilder();
            sb.Append(" SELECT COUNT(lt.LedgertransactionID) PatientCount,Round(IFNULL(SUM(plo.Amount),0)) NetAmount, 0 AvailAmtount,0 MonthlyPatientCount,0 MonthlyNetAmount ");
            sb.Append(" FROM `f_ledgertransaction` lt ");
            sb.Append(" INNER JOIN patient_labinvestigation_opd plo on plo.LedgertransactionID=lt.LedgertransactionID ");
            sb.Append(" INNER JOIN f_panel_master pm ON pm.`Panel_ID`=lt.`Panel_ID` ");
            sb.Append(" AND plo.`Date`>=@fromdate AND plo.`Date`<=@todate ");
            sb.Append(" AND pm.`Employee_ID`=@Employee_ID  ");
            using (dt = MySqlHelper.ExecuteDataset(con, CommandType.Text, sb.ToString(),
                 new MySqlParameter("@fromdate", string.Concat(DateTime.Now.ToString("yyyy-MM-dd"), " 00:00:00")),
                 new MySqlParameter("@todate", string.Concat(DateTime.Now.ToString("yyyy-MM-dd"), " 23:59:59")),
                 new MySqlParameter("@Employee_ID", EmployeeID)).Tables[0])
            {
                //--------------------------- for Monthly Count--------------------------
                sb = new StringBuilder();
                sb.Append("SELECT COUNT(lt.LedgertransactionID) MonthlyPatientCount,Round(IFNULL(SUM(plo.Amount),0))  MonthlyNetAmount");
                sb.Append(" FROM `f_ledgertransaction` lt");
                sb.Append(" INNER JOIN patient_labinvestigation_opd plo on plo.LedgertransactionID=lt.LedgertransactionID ");
                sb.Append(" INNER JOIN f_panel_master pm ON pm.`Panel_ID`=lt.`Panel_ID` AND pm.`Employee_ID`=@Employee_ID");
                sb.Append(" WHERE MONTH(lt.`Date`) = MONTH(CURRENT_DATE()) ");
                sb.Append(" AND YEAR(lt.`Date`) = YEAR(CURRENT_DATE())");
                DataTable dtCount = MySqlHelper.ExecuteDataset(con, CommandType.Text, sb.ToString(),
                 new MySqlParameter("@Employee_ID", EmployeeID)).Tables[0];
                if (dtCount.Rows.Count > 0)
                {

                    dt.Rows[0]["MonthlyPatientCount"] = dtCount.Rows[0]["MonthlyPatientCount"].ToString();
                    dt.Rows[0]["MonthlyNetAmount"] = dtCount.Rows[0]["MonthlyNetAmount"].ToString();
                    dt.AcceptChanges();


                }
                //---------------------------- end for monthly count--------------------

                string InvoiceTo = "";
                InvoiceTo =Util.GetString(MySqlHelper.ExecuteScalar(con, CommandType.Text, "SELECT InvoiceTo FROM f_panel_master WHERE Employee_ID = @Employee_ID ",
                    new MySqlParameter("@Employee_ID", EmployeeID)));
                sb = new StringBuilder();
                if (InvoiceTo != string.Empty)
                {
                    sb.Append(" SELECT Company_Name,IFNULL(AvailAmt,0) AvailAmt,IFNULL(SecurityDeposit,0) SecurityAmount,IFNULL(PaidAmount,0) PaidAmount FROM  ");
                    sb.Append(" (SELECT FPM.`Company_Name`,fpm.`SecurityDeposit`,IFNULL(imo.PaidAmount,0)PaidAmount, ");
                    sb.Append(" ROUND((IFNULL(imo.PaidAmount,0))-IFNULL(BillingAmount,0))AvailAmt  ");
                    sb.Append(" FROM f_panel_master fpm  ");
                    sb.Append(" LEFT JOIN(SELECT SUM(plo.Amount) BillingAmount,SUM(lt.`Adjustment`) PaidAmount1,pm1.InvoiceTo   ");
                    sb.Append(" FROM f_ledgertransaction lt  ");
                    sb.Append(" INNER JOIN patient_labinvestigation_opd plo on plo.LedgertransactionID=lt.LedgertransactionID ");
                    sb.Append(" INNER JOIN f_panel_master  pm1 ON pm1.panel_id=lt.panel_id WHERE pm1.InvoiceTo =@InvoiceTo  ");
                    sb.Append(" GROUP BY pm1.InvoiceTo) lt  ON lt.InvoiceTo=fpm.Panel_ID ");
                    sb.Append(" LEFT JOIN (  ");
                    sb.Append(" SELECT SUM(ino.ReceivedAmt) PaidAmount,ino.Panel_ID FROM invoicemaster_onaccount ino WHERE Panel_Id  =@InvoiceTo ");
                    sb.Append(" AND IFNULL(InvoiceNo,'')='' GROUP BY ino.Panel_ID) imo ON imo.Panel_ID=fpm.Panel_ID ");
                    sb.Append(" WHERE  fpm.Panel_Id  =@InvoiceTo) t  ");


                    DataTable dtadvanceamt = MySqlHelper.ExecuteDataset(con, CommandType.Text, sb.ToString(),
                 new MySqlParameter("@InvoiceTo", InvoiceTo)).Tables[0];
                    if (dtadvanceamt.Rows.Count > 0)
                    {
                        dt.Rows[0]["AvailAmtount"] = dtadvanceamt.Rows[0]["AvailAmt"].ToString();
                        dt.AcceptChanges();
                    }

                }
                if (dt.Rows.Count == 0)
                {
                    err.Add("status", false);
                    err.Add("message", "No Data Found");
                    err.Add("data", "");
                    return Request.CreateErrorResponse(HttpStatusCode.NoContent, err);
                }
                else
                {
                    err.Add("status", true);
                    err.Add("message", "Success");
                    err.Add("data", JArray.FromObject(dt));
                    return Request.CreateErrorResponse(HttpStatusCode.OK, err);
                }
            }
        }
        catch (Exception ex)
        {
            err.Add("status", false);
            err.Add("message", "Error Occured. Please contact Administrator.");
            err.Add("data", "");
            return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, err);
        }
        finally
        {
            con.Close();
            con.Dispose();
        }
    }
    [HttpPost]
    public HttpResponseMessage validateOTP([FromBody] ForgotPassword _forgotpassword)
    {
        HttpError err = new HttpError();
        if (_forgotpassword == null)
        {
            err.Add("status", false);
            err.Add("message", "Invalid JSON Format");
            err.Add("data", "");
            return Request.CreateErrorResponse(HttpStatusCode.BadRequest, err);
        }
        if (string.IsNullOrWhiteSpace(_forgotpassword.Mobile))
        {
            err.Add("status", false);
            err.Add("message", "Mobile can't be blank");
            err.Add("data", "");
            return Request.CreateErrorResponse(HttpStatusCode.BadRequest, err);
        }
        if (string.IsNullOrWhiteSpace(_forgotpassword.UserName))
        {
            err.Add("status", false);
            err.Add("message", "UserName can't be blank");
            err.Add("data", "");
            return Request.CreateErrorResponse(HttpStatusCode.BadRequest, err);
        }

        string UserType = "Employee";
        string EmployeeId = "";
        MySqlConnection con = Util.GetMySqlCon();
        con.Open();
        try
        {
              
            if (UserType.Trim() == "Employee")
            {
                StringBuilder sb = new StringBuilder();
                sb.Append("SELECT f.`code` FROM `forget_password` f");
                sb.Append(" JOIN (SELECT f.`EmployeeID` FROM `f_login` f JOIN `employee_master` e ON f.`EmployeeID`=e.`Employee_ID` WHERE  f.`UserName`=@UserName And (e.`Mobile`=@Mobile or e.Email=@Email) LIMIT 1)t");
                sb.Append(" ON t.EmployeeID=f.`Employee_Id`");
                sb.Append(" WHERE `code`=@code And UserType=@UserType AND `Employee_Id`=t.EmployeeID AND f.`isUsed`='0' AND date(`dtEntry`)=current_Date()");
                string otpupdate = Util.GetString(MySqlHelper.ExecuteScalar(con, CommandType.Text,
                    sb.ToString(),
                    new MySqlParameter("@Mobile", _forgotpassword.Mobile),
                     new MySqlParameter("@Email", _forgotpassword.Email),
                    new MySqlParameter("@UserName", _forgotpassword.UserName),
                    new MySqlParameter("@code", _forgotpassword.OTP),
                    new MySqlParameter("@UserType", UserType.Trim())));
                if (otpupdate == "")
                {
                    err.Add("status", false);
                    err.Add("message", "Incorrect Informations");
                    err.Add("data", "");
                    return Request.CreateErrorResponse(HttpStatusCode.BadRequest, err);
                }
                else
                {
                    sb = new StringBuilder();
                    sb.Append(" UPDATE forget_password f ");
                    sb.Append(" INNER JOIN f_login fl ON f.`Employee_Id`=fl.`EmployeeID`");
                    sb.Append(" INNER JOIN employee_master em ON em.`Employee_ID`=fl.`EmployeeID` ");
                    sb.Append(" AND f.`code`=@code AND fl.`UserName`=@UserName AND (em.`Mobile`=@Mobile or em.Email=@Email) AND f.`isUsed`=0 And UserType=@UserType ");
                    sb.Append(" SET f.`isUsed`=@isUsed,`dtUsed`=@dtUsed ");
                    MySqlHelper.ExecuteNonQuery(con, CommandType.Text,
                    sb.ToString(),
                    new MySqlParameter("@Mobile", _forgotpassword.Mobile),
                     new MySqlParameter("@Email", _forgotpassword.Email),
                    new MySqlParameter("@UserType", UserType.Trim()),
                    new MySqlParameter("@UserName", _forgotpassword.UserName),
                    new MySqlParameter("@code", _forgotpassword.OTP),
                    new MySqlParameter("@isUsed", "1"),
                    new MySqlParameter("@dtUsed", DateTime.Now));
                    EmployeeId = Util.GetString(MySqlHelper.ExecuteScalar(con, CommandType.Text,
                        "SELECT f.`EmployeeID` FROM `f_login` f JOIN `employee_master` e ON f.`EmployeeID`=e.`Employee_ID` WHERE (e.`Mobile`=@Mobile or e.`Email`=@EmailID)  AND f.`UserName`=@UserName LIMIT 1",
                        new MySqlParameter("@Mobile", _forgotpassword.Mobile),
                        new MySqlParameter("@EmailID", _forgotpassword.Email),
                        new MySqlParameter("@UserName", _forgotpassword.UserName)));
                   
                    err.Add("status", true);
                    err.Add("message", "Success");
                    err.Add("data", EmployeeId);
                    return Request.CreateErrorResponse(HttpStatusCode.OK, err);
                }
            }
            else if (UserType.Trim() == "PUP")
            {
                StringBuilder sb = new StringBuilder();
                sb.Append("SELECT f.`code` FROM `forget_password` f");
                sb.Append(" INNER JOIN f_panel_master fpm ON fpm.`Panel_ID`=f.`Employee_Id` And PanelUserID=@PanelUserID AND (fpm.`Mobile`=@Mobile OR fpm.`EmailID`=@EmailID) ");
                sb.Append(" WHERE `code`=@code AND UserType=@UserType AND f.`isUsed`='0' AND DATE(`dtEntry`)=CURRENT_DATE() ");

                string otpupdate1 = Util.GetString(MySqlHelper.ExecuteScalar(con, CommandType.Text,
                    sb.ToString(),
                    new MySqlParameter("@PanelUserID", _forgotpassword.UserName),
                    new MySqlParameter("@Mobile", _forgotpassword.Mobile),
                    new MySqlParameter("@EmailID", _forgotpassword.Email),
                    new MySqlParameter("@code", _forgotpassword.OTP),
                    new MySqlParameter("@UserType", UserType.Trim())));
                if (otpupdate1 == "")
                {
                    err.Add("status", false);
                    err.Add("message", "Incorrect Informations");
                    err.Add("data", "");
                    return Request.CreateErrorResponse(HttpStatusCode.BadRequest, err);
                }
                else
                {
                    sb = new StringBuilder();
                    sb.Append(" UPDATE forget_password f ");
                    sb.Append(" INNER JOIN f_panel_master fpm ON fpm.`Panel_ID`=f.`Employee_Id` And PanelUserID=@PanelUserID AND (fpm.`Mobile`=@Mobile OR fpm.`EmailID`=@EmailID) ");
                    sb.Append(" AND f.`code`=@code AND f.`isUsed`=0 And UserType=@UserType ");
                    sb.Append(" SET f.`isUsed`=@isUsed,`dtUsed`=@dtUsed ");
                    MySqlHelper.ExecuteNonQuery(con, CommandType.Text,
                    sb.ToString(),
                    new MySqlParameter("@PanelUserID", _forgotpassword.UserName),
                    new MySqlParameter("@Mobile", _forgotpassword.Mobile),
                    new MySqlParameter("@EmailID", _forgotpassword.Email),
                    new MySqlParameter("@UserType", UserType.Trim()),
                    new MySqlParameter("@code", _forgotpassword.OTP),
                    new MySqlParameter("@isUsed", "1"),
                    new MySqlParameter("@dtUsed", DateTime.Now));
                    EmployeeId = Util.GetString(MySqlHelper.ExecuteScalar(con, CommandType.Text,
                        "SELECT Panel_ID FROM f_panel_master WHERE  PanelType=@PanelType AND IsActive=@IsActive AND PanelUserID=@PanelUserID AND (mobile=@mobile OR EmailID=@EmailID)",
                        new MySqlParameter("@PanelType", "PUP"),
                        new MySqlParameter("@IsActive", "1"),
                        new MySqlParameter("@PanelUserID", _forgotpassword.UserName),
                        new MySqlParameter("@mobile", _forgotpassword.Mobile),
                        new MySqlParameter("@EmailID", _forgotpassword.Email)));
                   
                    err.Add("status", true);
                    err.Add("message", "Success");
                    err.Add("data", EmployeeId);
                    return Request.CreateErrorResponse(HttpStatusCode.OK, err);
                }
            }
            return Request.CreateErrorResponse(HttpStatusCode.BadRequest, err);
        }
        catch (Exception ex)
        {
            err.Add("status", false);
            err.Add("message", "Error Occured. Please contact Administrator.");
            err.Add("data", "");
            return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, err);
        }
        finally
        {
           con.Close();
            con.Dispose();
        }
       
    }
    [HttpGet]
    public HttpResponseMessage ResetPassword(string Password, string Employeeid)
    {
        HttpError err = new HttpError();
        if (string.IsNullOrWhiteSpace(Password))
        {
            err.Add("status", false);
            err.Add("message", "Password can't be blank");
            err.Add("data", "[]");
            return Request.CreateErrorResponse(HttpStatusCode.BadRequest, err);
        }
        if (string.IsNullOrWhiteSpace(Employeeid))
        {
            err.Add("status", false);
            err.Add("message", "Employeeid can't be blank");
            err.Add("data", "[]");
            return Request.CreateErrorResponse(HttpStatusCode.BadRequest, err);
        }
        MySqlConnection con = Util.GetMySqlCon();
        con.Open();
        try
        {
            string UserType = "Employee";
            if (UserType.Trim() == "Employee")
            {
                MySqlHelper.ExecuteNonQuery(con, CommandType.Text,
                    "UPDATE `f_login` SET PASSWORD=@password,InvalidPassword=0 WHERE `EmployeeID`=@Employee_Id",
                    new MySqlParameter("@password", Password),
                    new MySqlParameter("@Employee_Id", Employeeid));
               
                err.Add("status", true);
                err.Add("message", "Password successfully updated");
                err.Add("data", "[]");
            }
            else if (UserType.Trim() == "PUP")
            {
                MySqlHelper.ExecuteNonQuery(con, CommandType.Text,
                    " Update f_panel_master set PanelPassword=@PanelPassword where Panel_ID=@Panel_ID and IsActive=@IsActive And PanelType=@PanelType ",
                    new MySqlParameter("@PanelPassword", Password.Trim()),
                    new MySqlParameter("@Panel_ID", Employeeid),
                    new MySqlParameter("@IsActive", "1"),
                    new MySqlParameter("@PanelType", "PUP"));
                err.Add("status", true);
                err.Add("message", "Password successfully updated");
                err.Add("data", "[]");
            }
            return Request.CreateErrorResponse(HttpStatusCode.OK, err);
        }
        catch (Exception ex)
        {
            err.Add("status", false);
            err.Add("message", "Error Occured. Please contact Administrator.");
            err.Add("data", "[]");
            return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, err);
        }
        finally
        {
            con.Close();
            con.Dispose();
        }
    }
    [HttpGet]
    public HttpResponseMessage GetBanner()
    {
        HttpError err = new HttpError();
        MySqlConnection con = Util.GetMySqlCon();
        con.Open();
        try
        {
            string str1 = "";
            str1 = "SELECT ID,CONCAT('" + url + "/Design/B2BMobile/Images/','',if(Image='','default.jpg',Image))Images FROM App_B2B_Banner where IsActive=1 order by ShowOrder ";
            DataTable dt = MySqlHelper.ExecuteDataset(con, CommandType.Text, str1).Tables[0];
            if (dt.Rows.Count == 0)
            {
                err.Add("status", false);
                err.Add("message", "failure");
                err.Add("data", "[]");
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, err);
            }
            else
            {
                err.Add("status", true);
                err.Add("message", "exists");
                err.Add("data", JArray.FromObject(dt));
                return Request.CreateErrorResponse(HttpStatusCode.OK, err);
            }
        }
        catch (Exception ex)
        {
            ClassLog cl = new ClassLog();
            cl.errLog(ex);
            err.Add("status", false);
            err.Add("message", "Error Occured. Please contact Administrator.");
            err.Add("data", "[]");
            return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, err);
        }
        finally
        {
            con.Close();
            con.Dispose();
        }
    }
    [HttpGet]
    public HttpResponseMessage BindTabs()
    {
        HttpError err = new HttpError();
        MySqlConnection con = Util.GetMySqlCon();
        con.Open();
        try
        {
            DataTable dt = MySqlHelper.ExecuteDataset(con, CommandType.Text, "select ID,Title,ordering from app_b2B_tab where isactive=1 ORDER BY ordering").Tables[0];
            if (dt.Rows.Count == 0)
            {
                err.Add("status", false);
                err.Add("message", "failure");
                err.Add("data", "[]");
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, err);
            }
            else
            {
                err.Add("status", true);
                err.Add("message", "exists");
                err.Add("data", JArray.FromObject(dt));
                return Request.CreateErrorResponse(HttpStatusCode.OK, err);
            }
        }
        catch (Exception ex)
        {
            err.Add("status", false);
            err.Add("message", "Error Occured. Please contact Administrator.");
            err.Add("data", "[]");
            return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, err);
        }
        finally
        {
            con.Close();
            con.Dispose();
        }
    }
}
